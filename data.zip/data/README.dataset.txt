# Facial Emotion Detection > 2024-07-23 6:42am
https://universe.roboflow.com/asim-shah/facial-emotion-detection-mjeff

Provided by a Roboflow user
License: CC BY 4.0

